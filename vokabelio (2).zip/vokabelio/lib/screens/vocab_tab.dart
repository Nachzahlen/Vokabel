import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';

class VocabTab extends StatelessWidget {
  const VocabTab({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showVocabEditor(context),
        icon: const Icon(Icons.add),
        label: const Text('Neu'),
      ),
      body: s.vocabs.isEmpty
          ? const Center(child: Text('Noch keine Vokabeln – tippe auf „Neu“.'))
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 90),
              itemCount: s.vocabs.length,
              itemBuilder: (_, i) {
                final v = s.vocabs[i];
                return FadeIn(
                  delayMs: i * 30,
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Dismissible(
                      key: ValueKey(v.id),
                      direction: DismissDirection.endToStart,
                      background: Container(
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 24),
                        decoration: BoxDecoration(
                            color: Colors.red.shade100, borderRadius: BorderRadius.circular(24)),
                        child: const Icon(Icons.delete_outline, color: Colors.red),
                      ),
                      onDismissed: (_) => s.delete(v.id),
                      child: GestureDetector(
                        onTap: () => showVocabEditor(context, existing: v),
                        child: AppCard(
                          padding: const EdgeInsets.all(14),
                          child: Row(children: [
                            VocabVisual(v),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(v.word, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
                                Text(v.translation, style: TextStyle(color: Colors.grey.shade700)),
                                if (v.category.isNotEmpty)
                                  Padding(
                                    padding: const EdgeInsets.only(top: 6),
                                    child: Chip(
                                        label: Text(v.category, style: const TextStyle(fontSize: 11)),
                                        visualDensity: VisualDensity.compact,
                                        padding: EdgeInsets.zero),
                                  ),
                              ]),
                            ),
                            if (v.learned) const Icon(Icons.check_circle, color: Color(0xFF5CC9A7)),
                          ]),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

void showVocabEditor(BuildContext context, {Vocab? existing}) {
  final word = TextEditingController(text: existing?.word);
  final trans = TextEditingController(text: existing?.translation);
  final cat = TextEditingController(text: existing?.category);
  final url = TextEditingController(text: existing?.imageUrl);
  int? icon = existing?.iconIndex;

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSt) => Padding(
        padding: EdgeInsets.fromLTRB(20, 0, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(existing == null ? 'Neue Vokabel' : 'Vokabel bearbeiten',
                style: Theme.of(ctx).textTheme.titleLarge),
            const SizedBox(height: 16),
            TextField(controller: word, decoration: const InputDecoration(labelText: 'Wort')),
            const SizedBox(height: 10),
            TextField(controller: trans, decoration: const InputDecoration(labelText: 'Übersetzung')),
            const SizedBox(height: 10),
            TextField(controller: cat, decoration: const InputDecoration(labelText: 'Kategorie / Ordner (optional)')),
            const SizedBox(height: 10),
            TextField(controller: url, decoration: const InputDecoration(labelText: 'Bild-URL (optional)')),
            const SizedBox(height: 14),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (var i = 0; i < kIcons.length; i++)
                ChoiceChip(
                  label: Icon(kIcons[i], size: 20),
                  selected: icon == i,
                  onSelected: (sel) => setSt(() => icon = sel ? i : null),
                ),
            ]),
            const SizedBox(height: 18),
            FilledButton(
              onPressed: () {
                if (word.text.trim().isEmpty || trans.text.trim().isEmpty) return;
                final v = existing ??
                    Vocab(id: DateTime.now().microsecondsSinceEpoch.toString(), word: '', translation: '');
                v.word = word.text.trim();
                v.translation = trans.text.trim();
                v.category = cat.text.trim();
                v.imageUrl = url.text.trim().isEmpty ? null : url.text.trim();
                v.iconIndex = icon;
                context.read<AppState>().upsert(v);
                Navigator.pop(ctx);
              },
              child: const Text('Speichern'),
            ),
          ]),
        ),
      ),
    ),
  );
}
