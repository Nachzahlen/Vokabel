import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'plan_screen.dart';
import 'quiz_screen.dart';
import 'vocab_tab.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    const pages = [DashboardTab(), VocabTab(), ProfileTab()];
    return Scaffold(
      body: SafeArea(
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 250),
          child: KeyedSubtree(key: ValueKey(_tab), child: pages[_tab]),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Start'),
          NavigationDestination(icon: Icon(Icons.style_outlined), selectedIcon: Icon(Icons.style), label: 'Vokabeln'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }
}

class DashboardTab extends StatelessWidget {
  const DashboardTab({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final cs = Theme.of(context).colorScheme;
    final plan = s.plan;
    final session = s.todaySession();
    return ListView(padding: const EdgeInsets.all(20), children: [
      FadeIn(
        child: Row(children: [
          Expanded(
              child: Text('Hallo 👋',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold))),
          const CoinChip(),
        ]),
      ),
      const SizedBox(height: 20),
      FadeIn(
        delayMs: 100,
        child: AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(plan == null ? 'Gesamtfortschritt' : 'Fortschritt bis zum Test',
                style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 14),
            TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: s.progress),
              duration: const Duration(milliseconds: 700),
              curve: Curves.easeOutCubic,
              builder: (_, v, __) => ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: LinearProgressIndicator(value: v, minHeight: 12, color: cs.secondary,
                    backgroundColor: cs.secondary.withOpacity(0.15)),
              ),
            ),
            const SizedBox(height: 8),
            Text('${(s.progress * 100).round()} % gelernt',
                style: TextStyle(color: Colors.grey.shade600)),
          ]),
        ),
      ),
      const SizedBox(height: 16),
      FadeIn(
        delayMs: 200,
        child: AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(Icons.event_available, color: cs.primary),
              const SizedBox(width: 10),
              Expanded(
                  child: Text(
                      plan == null
                          ? 'Kein Test geplant'
                          : 'Test am ${plan.testDate.day}.${plan.testDate.month}.${plan.testDate.year}',
                      style: const TextStyle(fontWeight: FontWeight.w600))),
            ]),
            const SizedBox(height: 10),
            Text(
              plan == null
                  ? 'Plane deinen nächsten Test – die App erstellt dir einen Lernplan.'
                  : 'Noch ${s.daysLeft} Tag(e) · heute ${session.length} Vokabeln (davon ${s.newPerToday} neu)',
              style: TextStyle(color: Colors.grey.shade700),
            ),
            const SizedBox(height: 14),
            OutlinedButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PlanScreen())),
              child: Text(plan == null ? 'Test planen' : 'Plan ändern'),
            ),
          ]),
        ),
      ),
      const SizedBox(height: 24),
      FadeIn(
        delayMs: 300,
        child: FilledButton.icon(
          icon: const Icon(Icons.play_arrow_rounded),
          label: Text(plan == null ? 'Alle Vokabeln üben' : 'Heutige Abfrage starten'),
          onPressed: session.isEmpty
              ? null
              : () => Navigator.push(context, MaterialPageRoute(builder: (_) => QuizScreen(items: session))),
        ),
      ),
    ]);
  }
}

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final cs = Theme.of(context).colorScheme;
    return ListView(padding: const EdgeInsets.all(20), children: [
      FadeIn(
        child: AppCard(
          child: Column(children: [
            CircleAvatar(radius: 38, backgroundColor: cs.primaryContainer,
                child: Icon(Icons.person, size: 40, color: cs.primary)),
            const SizedBox(height: 12),
            Text(s.email ?? '', style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 16),
            const CoinChip(),
            const SizedBox(height: 16),
            Text('${s.vocabs.length} Vokabeln · ${s.vocabs.where((v) => v.learned).length} gelernt',
                style: TextStyle(color: Colors.grey.shade600)),
          ]),
        ),
      ),
      const SizedBox(height: 20),
      OutlinedButton.icon(
          onPressed: s.logout, icon: const Icon(Icons.logout), label: const Text('Abmelden')),
    ]);
  }
}
