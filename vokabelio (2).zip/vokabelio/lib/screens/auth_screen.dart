import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _mail = TextEditingController();
  final _pw = TextEditingController();
  bool _register = false;
  String? _error;

  void _submit() {
    final s = context.read<AppState>();
    final err = _register ? s.register(_mail.text, _pw.text) : s.login(_mail.text, _pw.text);
    setState(() => _error = err);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(28),
            child: FadeIn(
              child: Column(children: [
                Icon(Icons.auto_stories_rounded, size: 72, color: cs.primary),
                const SizedBox(height: 12),
                Text('Vokabelio',
                    style: Theme.of(context)
                        .textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(_register ? 'Neues Konto erstellen' : 'Willkommen zurück',
                    style: TextStyle(color: Colors.grey.shade600)),
                const SizedBox(height: 32),
                TextField(
                    controller: _mail,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(labelText: 'E-Mail')),
                const SizedBox(height: 14),
                TextField(
                    controller: _pw,
                    obscureText: true,
                    onSubmitted: (_) => _submit(),
                    decoration: const InputDecoration(labelText: 'Passwort')),
                AnimatedSize(
                  duration: const Duration(milliseconds: 250),
                  child: _error == null
                      ? const SizedBox(height: 12)
                      : Padding(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          child: Text(_error!, style: TextStyle(color: cs.error))),
                ),
                FilledButton(onPressed: _submit, child: Text(_register ? 'Registrieren' : 'Anmelden')),
                TextButton(
                  onPressed: () => setState(() {
                    _register = !_register;
                    _error = null;
                  }),
                  child: Text(_register ? 'Schon ein Konto? Anmelden' : 'Noch kein Konto? Registrieren'),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
