import 'dart:math';
import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';

class QuizScreen extends StatefulWidget {
  final List<Vocab> items;
  const QuizScreen({super.key, required this.items});
  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  static const _green = Color(0xFF5CC9A7);
  static const _red = Color(0xFFFF8A80);
  final _confetti = ConfettiController(duration: const Duration(seconds: 3));
  int _i = 0, _correct = 0;
  String? _picked;
  List<String> _options = [];

  Vocab get _v => widget.items[_i];
  bool get _done => _i >= widget.items.length;

  @override
  void initState() {
    super.initState();
    _buildOptions();
  }

  @override
  void dispose() {
    _confetti.dispose();
    super.dispose();
  }

  void _buildOptions() {
    if (_done) return;
    final pool = context.read<AppState>().vocabs
        .where((x) => x.id != _v.id && x.translation != _v.translation)
        .map((x) => x.translation).toSet().toList()..shuffle();
    _options = [_v.translation, ...pool.take(3)]..shuffle();
  }

  void _pick(String opt) {
    if (_picked != null) return;
    final ok = opt == _v.translation;
    setState(() {
      _picked = opt;
      if (ok) _correct++;
    });
    context.read<AppState>().answer(_v, ok);
    Future.delayed(const Duration(milliseconds: 1000), () {
      if (!mounted) return;
      setState(() {
        _i++;
        _picked = null;
        _buildOptions();
      });
      if (_done && _correct / widget.items.length >= 0.8) _confetti.play();
    });
  }

  Color _color(String opt) {
    if (_picked == null) return Colors.white;
    if (opt == _v.translation) return _green.withOpacity(0.35);
    if (opt == _picked) return _red.withOpacity(0.35);
    return Colors.white;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: _done
            ? const Text('Ergebnis')
            : TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: _i / widget.items.length),
                duration: const Duration(milliseconds: 400),
                builder: (_, v, __) => ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(value: v, minHeight: 10)),
              ),
        actions: const [Padding(padding: EdgeInsets.only(right: 16), child: CoinChip())],
      ),
      body: Stack(alignment: Alignment.topCenter, children: [
        Padding(padding: const EdgeInsets.all(20), child: _done ? _result() : _question()),
        ConfettiWidget(
          confettiController: _confetti,
          blastDirection: pi / 2,
          emissionFrequency: 0.05,
          numberOfParticles: 20,
          gravity: 0.2,
        ),
      ]),
    );
  }

  Widget _question() {
    return Column(key: ValueKey(_i), children: [
      FadeIn(
        child: AnimatedScale(
          scale: _picked == null ? 1 : 1.03,
          duration: const Duration(milliseconds: 200),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 20),
            decoration: BoxDecoration(
              color: _picked == null
                  ? Colors.white
                  : (_picked == _v.translation ? _green.withOpacity(0.25) : _red.withOpacity(0.25)),
              borderRadius: BorderRadius.circular(28),
            ),
            child: Column(children: [
              VocabVisual(_v, size: 96),
              const SizedBox(height: 18),
              Text(_v.word,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
            ]),
          ),
        ),
      ),
      const SizedBox(height: 24),
      for (final o in _options)
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: GestureDetector(
            onTap: () => _pick(o),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 18),
              decoration: BoxDecoration(color: _color(o), borderRadius: BorderRadius.circular(18)),
              child: Center(child: Text(o, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w500))),
            ),
          ),
        ),
    ]);
  }

  Widget _result() {
    final total = widget.items.length;
    final passed = _correct / total >= 0.8;
    return FadeIn(
      child: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(passed ? Icons.emoji_events : Icons.trending_up, size: 90,
              color: passed ? const Color(0xFFF2B100) : Theme.of(context).colorScheme.primary),
          const SizedBox(height: 16),
          Text(passed ? 'Bestanden! 🎉' : 'Weiter üben 💪',
              style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 8),
          Text('$_correct von $total richtig · +${_correct * kCoinsPerCorrect} Coins'),
          const SizedBox(height: 32),
          FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Fertig')),
        ]),
      ),
    );
  }
}
