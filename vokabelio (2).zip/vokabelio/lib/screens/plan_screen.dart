import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';

class PlanScreen extends StatefulWidget {
  const PlanScreen({super.key});
  @override
  State<PlanScreen> createState() => _PlanScreenState();
}

class _PlanScreenState extends State<PlanScreen> {
  late DateTime _date;
  late int _count;

  @override
  void initState() {
    super.initState();
    final s = context.read<AppState>();
    _date = s.plan?.testDate ?? DateTime.now().add(const Duration(days: 7));
    final max = s.vocabs.isEmpty ? 1 : s.vocabs.length;
    _count = (s.plan?.ids.length ?? 20).clamp(1, max);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final days = DateTime(_date.year, _date.month, _date.day).difference(today).inDays.clamp(1, 9999);
    final perDay = (_count / days).ceil();
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Test planen'), backgroundColor: Colors.transparent),
      body: s.vocabs.isEmpty
          ? const Center(child: Text('Lege zuerst Vokabeln an.'))
          : ListView(padding: const EdgeInsets.all(20), children: [
              FadeIn(
                child: AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Wann ist der Test?', style: TextStyle(fontWeight: FontWeight.w600)),
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      icon: const Icon(Icons.calendar_month),
                      label: Text('${_date.day}.${_date.month}.${_date.year}'),
                      onPressed: () async {
                        final d = await showDatePicker(
                            context: context,
                            initialDate: _date.isBefore(today) ? today : _date,
                            firstDate: today,
                            lastDate: today.add(const Duration(days: 365)));
                        if (d != null) setState(() => _date = d);
                      },
                    ),
                    const SizedBox(height: 22),
                    const Text('Wie viele Vokabeln werden abgefragt?', style: TextStyle(fontWeight: FontWeight.w600)),
                    const SizedBox(height: 6),
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      IconButton.filledTonal(
                          onPressed: _count > 1 ? () => setState(() => _count--) : null,
                          icon: const Icon(Icons.remove)),
                      SizedBox(
                          width: 90,
                          child: Center(
                              child: Text('$_count',
                                  style: Theme.of(context).textTheme.headlineMedium))),
                      IconButton.filledTonal(
                          onPressed: _count < s.vocabs.length ? () => setState(() => _count++) : null,
                          icon: const Icon(Icons.add)),
                    ]),
                    Center(
                        child: Text('von ${s.vocabs.length} vorhandenen',
                            style: TextStyle(color: Colors.grey.shade600))),
                  ]),
                ),
              ),
              const SizedBox(height: 16),
              FadeIn(
                delayMs: 150,
                child: AppCard(
                  child: Row(children: [
                    Icon(Icons.auto_awesome, color: cs.secondary),
                    const SizedBox(width: 12),
                    Expanded(
                        child: Text(
                            'Lernplan: $days Tag(e) → ca. $perDay neue Vokabeln pro Tag. '
                            'Die App passt die Tagesmenge automatisch an deinen Fortschritt an.')),
                  ]),
                ),
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: () {
                  s.createPlan(_date, _count);
                  Navigator.pop(context);
                },
                child: const Text('Plan speichern'),
              ),
              if (s.plan != null)
                TextButton(
                    onPressed: () {
                      s.clearPlan();
                      Navigator.pop(context);
                    },
                    child: const Text('Plan löschen')),
            ]),
    );
  }
}
