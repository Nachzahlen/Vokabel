import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models.dart';

/// Coins pro richtig beantworteter Vokabel (hier zentral änderbar).
const int kCoinsPerCorrect = 1;

class AppState extends ChangeNotifier {
  late SharedPreferences _p;
  String? email;
  int coins = 0;
  List<Vocab> vocabs = [];
  TestPlan? plan;

  bool get loggedIn => email != null;

  Future<void> init() async {
    _p = await SharedPreferences.getInstance();
    final s = _p.getString('session');
    if (s != null) _load(s);
  }

  // ---------- Auth ----------
  String _hash(String pw) => sha256.convert(utf8.encode(pw)).toString();
  Map<String, dynamic> get _users => jsonDecode(_p.getString('users') ?? '{}');

  String? register(String mail, String pw) {
    mail = mail.trim().toLowerCase();
    if (!mail.contains('@') || pw.length < 6) {
      return 'Gültige E-Mail und mind. 6 Zeichen Passwort nötig.';
    }
    final users = _users;
    if (users.containsKey(mail)) return 'Diese E-Mail ist bereits registriert.';
    users[mail] = _hash(pw);
    _p.setString('users', jsonEncode(users));
    email = mail;
    coins = 0;
    plan = null;
    vocabs = [
      Vocab(id: 'd1', word: 'apple', translation: 'Apfel', category: 'Essen', iconIndex: 0),
      Vocab(id: 'd2', word: 'dog', translation: 'Hund', category: 'Tiere', iconIndex: 1),
      Vocab(id: 'd3', word: 'house', translation: 'Haus', category: 'Alltag', iconIndex: 2),
      Vocab(id: 'd4', word: 'car', translation: 'Auto', category: 'Alltag', iconIndex: 3),
      Vocab(id: 'd5', word: 'book', translation: 'Buch', category: 'Schule', iconIndex: 10),
    ];
    _p.setString('session', mail);
    _commit();
    return null;
  }

  String? login(String mail, String pw) {
    mail = mail.trim().toLowerCase();
    if (_users[mail] != _hash(pw)) return 'E-Mail oder Passwort falsch.';
    _p.setString('session', mail);
    _load(mail);
    notifyListeners();
    return null;
  }

  void logout() {
    _p.remove('session');
    email = null;
    notifyListeners();
  }

  void _load(String mail) {
    email = mail;
    final d = jsonDecode(_p.getString('data_$mail') ?? '{}');
    coins = d['coins'] ?? 0;
    vocabs = ((d['vocabs'] ?? []) as List).map((e) => Vocab.fromJson(e)).toList();
    plan = d['plan'] == null ? null : TestPlan.fromJson(d['plan']);
  }

  void _commit() {
    _p.setString('data_$email', jsonEncode({
      'coins': coins,
      'vocabs': vocabs.map((v) => v.toJson()).toList(),
      'plan': plan?.toJson(),
    }));
    notifyListeners();
  }

  // ---------- Vokabeln ----------
  void upsert(Vocab v) {
    final i = vocabs.indexWhere((x) => x.id == v.id);
    i >= 0 ? vocabs[i] = v : vocabs.add(v);
    _commit();
  }

  void delete(String id) {
    vocabs.removeWhere((v) => v.id == id);
    if (plan != null) {
      plan!.ids.remove(id);
      if (plan!.ids.isEmpty) plan = null;
    }
    _commit();
  }

  // ---------- Testplanung ----------
  List<Vocab> get planVocabs =>
      plan == null ? [] : vocabs.where((v) => plan!.ids.contains(v.id)).toList();

  int get daysLeft {
    if (plan == null) return 0;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    return plan!.testDate.difference(today).inDays.clamp(1, 9999);
  }

  void createPlan(DateTime date, int count) {
    // Schwächste Vokabeln zuerst, dann zufällig
    final pool = [...vocabs]..shuffle();
    pool.sort((a, b) => a.streak.compareTo(b.streak));
    final chosen = pool.take(count).toList();
    for (final v in chosen) {
      v.seen = false;
      v.streak = 0;
    }
    plan = TestPlan(DateTime(date.year, date.month, date.day), chosen.map((v) => v.id).toList());
    _commit();
  }

  void clearPlan() {
    plan = null;
    _commit();
  }

  /// Neue Vokabeln für heute = Restmenge / verbleibende Tage (rundet auf).
  /// Passt sich täglich automatisch an; am Testtag kommt alles Offene dran.
  int get newPerToday {
    final fresh = planVocabs.where((v) => !v.learned && !v.seen).length;
    return daysLeft <= 1 ? fresh : (fresh / daysLeft).ceil();
  }

  /// Tagesplan = alle angefangenen, noch nicht gelernten Vokabeln (Wiederholung)
  /// + die heutigen neuen Vokabeln.
  List<Vocab> todaySession() {
    if (plan == null) return ([...vocabs]..shuffle());
    final open = planVocabs.where((v) => !v.learned).toList();
    final review = open.where((v) => v.seen).toList();
    final fresh = open.where((v) => !v.seen).take(newPerToday).toList();
    final list = [...review, ...fresh];
    return (list.isEmpty ? [...planVocabs] : list)..shuffle();
  }

  double get progress {
    final list = plan == null ? vocabs : planVocabs;
    if (list.isEmpty) return 0;
    return list.where((v) => v.learned).length / list.length;
  }

  // ---------- Quiz ----------
  void answer(Vocab v, bool correct) {
    v.seen = true;
    if (correct) {
      v.streak++;
      coins += kCoinsPerCorrect;
    } else {
      v.streak = 0;
    }
    _commit();
  }
}
