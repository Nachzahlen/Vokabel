import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../state/app_state.dart';

/// Sanftes Einblenden + leichtes Hochgleiten.
class FadeIn extends StatelessWidget {
  final Widget child;
  final int delayMs;
  const FadeIn({super.key, required this.child, this.delayMs = 0});

  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: 1),
        duration: Duration(milliseconds: 450 + delayMs),
        curve: Curves.easeOutCubic,
        builder: (_, t, c) => Opacity(
            opacity: t, child: Transform.translate(offset: Offset(0, 16 * (1 - t)), child: c)),
        child: child,
      );
}

class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  const AppCard({super.key, required this.child, this.padding = const EdgeInsets.all(20)});

  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: padding,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(color: Colors.blueGrey.withOpacity(0.08), blurRadius: 20, offset: const Offset(0, 6))
          ],
        ),
        child: child,
      );
}

class CoinChip extends StatelessWidget {
  const CoinChip({super.key});

  @override
  Widget build(BuildContext context) {
    final coins = context.watch<AppState>().coins;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
          color: const Color(0xFFFFF3CD), borderRadius: BorderRadius.circular(20)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.monetization_on, color: Color(0xFFF2B100), size: 20),
        const SizedBox(width: 6),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          transitionBuilder: (c, a) => ScaleTransition(scale: a, child: c),
          child: Text('$coins',
              key: ValueKey(coins), style: const TextStyle(fontWeight: FontWeight.bold)),
        ),
      ]),
    );
  }
}

/// Bild-URL oder Icon einer Vokabel.
class VocabVisual extends StatelessWidget {
  final Vocab v;
  final double size;
  const VocabVisual(this.v, {super.key, this.size = 56});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final fallback = Icon(
        v.iconIndex != null ? kIcons[v.iconIndex!] : Icons.translate,
        size: size * 0.55, color: cs.primary);
    Widget inner = fallback;
    if (v.imageUrl != null && v.imageUrl!.isNotEmpty) {
      inner = Image.network(v.imageUrl!,
          width: size, height: size, fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => fallback);
    }
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
          color: cs.primaryContainer.withOpacity(0.5), borderRadius: BorderRadius.circular(16)),
      clipBehavior: Clip.antiAlias,
      alignment: Alignment.center,
      child: inner,
    );
  }
}
