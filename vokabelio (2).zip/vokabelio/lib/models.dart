import 'package:flutter/material.dart';

const kIcons = <IconData>[
  Icons.apple, Icons.pets, Icons.home, Icons.directions_car, Icons.school,
  Icons.restaurant, Icons.park, Icons.sports_soccer, Icons.music_note,
  Icons.flight, Icons.book, Icons.favorite,
];

class Vocab {
  final String id;
  String word, translation, category;
  String? imageUrl;
  int? iconIndex;
  bool seen; // in einer Lernsession schon vorgekommen
  int streak; // richtige Antworten in Folge

  Vocab({
    required this.id,
    required this.word,
    required this.translation,
    this.category = '',
    this.imageUrl,
    this.iconIndex,
    this.seen = false,
    this.streak = 0,
  });

  bool get learned => streak >= 2;

  Map<String, dynamic> toJson() => {
        'id': id, 'word': word, 'translation': translation, 'category': category,
        'imageUrl': imageUrl, 'iconIndex': iconIndex, 'seen': seen, 'streak': streak,
      };

  factory Vocab.fromJson(Map<String, dynamic> j) => Vocab(
        id: j['id'], word: j['word'], translation: j['translation'],
        category: j['category'] ?? '', imageUrl: j['imageUrl'],
        iconIndex: j['iconIndex'], seen: j['seen'] ?? false, streak: j['streak'] ?? 0,
      );
}

class TestPlan {
  final DateTime testDate;
  final List<String> ids;
  TestPlan(this.testDate, this.ids);

  Map<String, dynamic> toJson() => {'date': testDate.toIso8601String(), 'ids': ids};
  factory TestPlan.fromJson(Map<String, dynamic> j) =>
      TestPlan(DateTime.parse(j['date']), List<String>.from(j['ids']));
}
