# Vokabelio

## APK bauen
**Lokal:** `./build_apk.sh` → `build/app/outputs/flutter-apk/app-release.apk`

**Ohne Installation (GitHub):** Projekt in ein GitHub-Repo pushen → Tab *Actions* →
Workflow *Build APK* → fertige `vokabelio-apk` unter *Artifacts* herunterladen.

## Installieren
APK aufs Handy kopieren, antippen und „Installation aus unbekannten Quellen“ erlauben.

## Struktur
lib/main.dart · models.dart · state/app_state.dart (Provider) · screens/ · widgets/
