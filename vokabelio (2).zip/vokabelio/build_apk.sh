#!/usr/bin/env bash
# Baut eine installierbare Release-APK. Voraussetzung: Flutter SDK + Android SDK (flutter doctor).
set -euo pipefail
cd "$(dirname "$0")"

# 1) Android-Projektgerüst erzeugen (lib/ und pubspec.yaml bleiben unverändert)
[ -d android ] || flutter create . --platforms=android --org com.vokabelio --project-name vokabelio
rm -rf test

# 2) INTERNET-Berechtigung ins Haupt-Manifest (nötig für Bild-URLs im Release-Build)
M=android/app/src/main/AndroidManifest.xml
grep -q 'android.permission.INTERNET' "$M" || \
  sed -i 's#<application#<uses-permission android:name="android.permission.INTERNET"/>\n    <application#' "$M"
sed -i 's#android:label="[^"]*"#android:label="Vokabelio"#' "$M"

# 3) Bauen
flutter pub get
flutter build apk --release

echo
echo "Fertig: build/app/outputs/flutter-apk/app-release.apk"
